var searchData=
[
  ['espais_182',['espais',['../classProcessador.html#a6314a00a66069d50416a430ec8646798',1,'Processador']]],
  ['espera_183',['espera',['../classAreaDeEspera.html#a769da9dc7622aececaf241f0b816c13e',1,'AreaDeEspera']]]
];
