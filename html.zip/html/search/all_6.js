var searchData=
[
  ['leer_5fcluster_57',['leer_cluster',['../classCluster.html#a95a28cc6425e773acf85c31ba21f82a8',1,'Cluster']]],
  ['left_58',['left',['../structBinTree_1_1Node.html#a265a6367635a38838e6a6366564be78d',1,'BinTree::Node::left()'],['../classBinTree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree::left()']]],
  ['llegeix_5fareadeespera_59',['llegeix_AreaDeEspera',['../classAreaDeEspera.html#a8c9c7dcf94633f1ab28cff1ca88a382b',1,'AreaDeEspera']]],
  ['llegeix_5fcluster_60',['llegeix_cluster',['../classCluster.html#af905ee5bec140b7cf47ce34797b80521',1,'Cluster']]],
  ['llegeix_5fprioritat_61',['llegeix_prioritat',['../classPrioritat.html#adc16189a81639312f382eafa294244ac',1,'Prioritat']]],
  ['llegeix_5fproces_62',['llegeix_proces',['../classProces.html#aa564be382cd4adab56095d3756b062d1',1,'Proces']]],
  ['llegeix_5fprocessador_63',['llegeix_processador',['../classProcessador.html#a2b6715270fb42b5939ee4bf4abbd2b47',1,'Processador']]]
];
