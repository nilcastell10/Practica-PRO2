var searchData=
[
  ['id_184',['id',['../classProcessador.html#a83b52149037f6ad2a7868c0ca901bd92',1,'Processador']]],
  ['id_5fpos_185',['id_pos',['../classProcessador.html#a4e10a156b730eb83d92523d87686d9a3',1,'Processador']]],
  ['ide_186',['ide',['../classPrioritat.html#aefc5b65af14b01081c3790dad47dd630',1,'Prioritat']]]
];
