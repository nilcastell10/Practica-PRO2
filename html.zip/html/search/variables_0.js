var searchData=
[
  ['capacitat_179',['capacitat',['../classProcessador.html#a35ebd75a37072e10f3fd521cdfbe5f87',1,'Processador']]],
  ['clu_180',['clu',['../classCluster.html#a98c55c8468dfa0dc7aa62ddce58efc05',1,'Cluster']]],
  ['cua_181',['cua',['../classPrioritat.html#aab760be9b256fc98d875008f77acff59',1,'Prioritat']]]
];
