var indexSectionsWithContent =
{
  0: "abcehilmnprtvx",
  1: "abcnp",
  2: "abcp",
  3: "abcehilmnprtv",
  4: "ceilmnprtx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables"
};

