var searchData=
[
  ['hueco_5fajustado_48',['hueco_ajustado',['../classProcessador.html#a9a413b51e843aa36ffacefcff431890d',1,'Processador']]]
];
