var searchData=
[
  ['prioritat_101',['Prioritat',['../classPrioritat.html',1,'']]],
  ['proces_102',['Proces',['../classProces.html',1,'']]],
  ['processador_103',['Processador',['../classProcessador.html',1,'']]]
];
