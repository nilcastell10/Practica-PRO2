var searchData=
[
  ['te_5fprocessos_176',['te_processos',['../classProcessador.html#a1be90ad90f55a909a371ae97e7688f20',1,'Processador']]],
  ['treure_5ftemps_177',['treure_temps',['../classProces.html#aefe9f75ea3932e17fe1f920b20b6b309',1,'Proces']]]
];
