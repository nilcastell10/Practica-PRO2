var searchData=
[
  ['te_5fprocessos_91',['te_processos',['../classProcessador.html#a1be90ad90f55a909a371ae97e7688f20',1,'Processador']]],
  ['temps_92',['temps',['../classProces.html#a7b9c0db0212d9727e7c3c5b7fdd6ea5d',1,'Proces']]],
  ['treure_5ftemps_93',['treure_temps',['../classProces.html#aefe9f75ea3932e17fe1f920b20b6b309',1,'Proces']]]
];
