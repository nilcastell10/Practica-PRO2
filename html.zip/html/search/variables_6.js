var searchData=
[
  ['p_192',['p',['../classBinTree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['pacceptat_193',['pacceptat',['../classPrioritat.html#a0d494fdca806bad1e3130761a254be01',1,'Prioritat']]],
  ['pos_5fproces_194',['pos_proces',['../classProcessador.html#a73fc73271b939428e2306e4052760a1a',1,'Processador']]],
  ['pr_195',['pr',['../classPrioritat.html#a95f3008406bb2b22b172d6a61a0a0117',1,'Prioritat']]],
  ['prefusat_196',['prefusat',['../classPrioritat.html#a75de315e3647f1a10582ebdd7e299407',1,'Prioritat']]]
];
