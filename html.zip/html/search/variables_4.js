var searchData=
[
  ['mapa_188',['mapa',['../classCluster.html#a496f1c23ab3c191364b70bd1748fe884',1,'Cluster']]],
  ['memlliure_189',['memlliure',['../classProcessador.html#ae72b71bf67962c85534218f9f23bebbc',1,'Processador']]],
  ['memoc_190',['memoc',['../classProces.html#a709928b7e8cc36f918f2b741a8eac5a1',1,'Proces']]]
];
