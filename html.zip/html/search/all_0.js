var searchData=
[
  ['actualitza_0',['actualitza',['../classProcessador.html#ae4fee5e45c3734d3fa33e27a10e1202c',1,'Processador']]],
  ['afegeix_1',['afegeix',['../classPrioritat.html#a55d55ab3475bb3b9060d36331383f5ea',1,'Prioritat']]],
  ['afegeix_5fproces_2',['afegeix_proces',['../classProcessador.html#a174074180050858d7bcc8cca68a33d18',1,'Processador']]],
  ['alta_5fprioridad_3',['alta_prioridad',['../classAreaDeEspera.html#af936fc0ccc5a2a0c4a5d15e287d5cdf1',1,'AreaDeEspera']]],
  ['alta_5fproceso_5fespera_4',['alta_proceso_espera',['../classAreaDeEspera.html#ad6e400dd6445dac9a4b938a3d6ea6c7a',1,'AreaDeEspera']]],
  ['alta_5fproceso_5fprocesador_5',['alta_proceso_procesador',['../classCluster.html#a8e558b61cfb5d5da2ba6a96dbfa15404',1,'Cluster']]],
  ['areadeespera_6',['AreaDeEspera',['../classAreaDeEspera.html',1,'AreaDeEspera'],['../classAreaDeEspera.html#ab2bc3ee3df5481c05f7d6cd468eaf225',1,'AreaDeEspera::AreaDeEspera()']]],
  ['areadeespera_2ecc_7',['AreaDeEspera.cc',['../AreaDeEspera_8cc.html',1,'']]],
  ['areadeespera_2ehh_8',['AreaDeEspera.hh',['../AreaDeEspera_8hh.html',1,'']]],
  ['avanzar_5ftiempo_9',['avanzar_tiempo',['../classCluster.html#a22f7aaac24597130683f30fd4f72e211',1,'Cluster']]]
];
