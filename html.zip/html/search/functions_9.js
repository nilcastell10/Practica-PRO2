var searchData=
[
  ['passa_170',['passa',['../classCluster.html#ad539d3319a73546703744911830b3fda',1,'Cluster']]],
  ['passa_5fcluster_171',['passa_cluster',['../classCluster.html#ad3352f1ae80965ec3187d4e210ad985a',1,'Cluster']]],
  ['prioritat_172',['Prioritat',['../classPrioritat.html#af2ad973a8bc814685bc8f05aaa3a2a8a',1,'Prioritat::Prioritat()'],['../classPrioritat.html#aee7ea242f60b1f5ab03b8b2457fc5555',1,'Prioritat::Prioritat(const string &amp;id)']]],
  ['proces_173',['Proces',['../classProces.html#a4d0ab1884d133bf380c6bbb580dcc853',1,'Proces']]],
  ['processador_174',['Processador',['../classProcessador.html#a96893b8af3688640cfa4125b629e0512',1,'Processador::Processador()'],['../classProcessador.html#a783e297a1c41ec33f22fab67d7c0abe2',1,'Processador::Processador(const string &amp;ide)'],['../classProcessador.html#a966c2706a2ab9d6fcfec1ee164117fea',1,'Processador::Processador(const string &amp;ide, int &amp;me)']]]
];
